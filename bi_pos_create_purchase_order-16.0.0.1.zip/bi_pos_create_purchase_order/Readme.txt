Version 16.0.0.1: (24/08/23)
	- Fixed issue when in pos side create a purchase order that time some conditions going into infinite loop fixed the issue.