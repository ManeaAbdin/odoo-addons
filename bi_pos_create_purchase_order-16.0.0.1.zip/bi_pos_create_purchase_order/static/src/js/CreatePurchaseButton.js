odoo.define('bi_pos_create_purchase_order.CreatePurchaseButton', function(require) {
	"use strict";

	const PosComponent = require('point_of_sale.PosComponent');
	const ProductScreen = require('point_of_sale.ProductScreen');
	const { useListener } = require("@web/core/utils/hooks");
	const Registries = require('point_of_sale.Registries');


   	class CreatePurchaseButton extends PosComponent {
	   	setup() {
            super.setup();
            useListener('click', this.onClick);
        }

		async onClick() {
			let self = this;
				
			let order = self.env.pos.get_order();
			let cashier_id = self.env.pos.user.id;

			let partner_id = false
			if (order.get_partner() != null)
				partner_id = order.get_partner().id;
			
			if (!partner_id) {
				self.showPopup('ErrorPopup', {
					title: self.env._t('Unknown customer'),
					body: self.env._t('You cannot Create Purchase Order. Select customer first.'),
				});
				return;
			}

			let orderlines = order.get_orderlines();
			if (orderlines.length === 0) {
				self.showPopup('ErrorPopup', {
					title: self.env._t('Empty Order'),
					body: self.env._t('There must be at least one product in your order before Add a note.'),
				});
				return;
			}
			let po_state = self.env.pos.config.po_state
			let pos_product_list = [];
			for (let i = 0; i < orderlines.length; i++) {
				let product_items = {
					'id': orderlines[i].product.id,
					'quantity': orderlines[i].quantity,
					'uom_id': orderlines[i].product.uom_id[0],
					'price': orderlines[i].price,
					'discount': orderlines[i].discount,
				};
				
				pos_product_list.push({'product': product_items });
			}
			this.rpc({
				model: 'purchase.order',
				method: 'create_purchase_order_ui',
				args: [partner_id, partner_id, pos_product_list, cashier_id,po_state,order.pos_session_id],
			
			}).then(function(output) {
				while (order.get_orderlines().length > 0) {
					orderlines.forEach(function (line) {
						order.remove_orderline(line);
					});
				}
				order.set_partner(false);
				alert('Purchase Order Created !!!! : '+ output);
			});
		}
	}
   
   CreatePurchaseButton.template = 'CreatePurchaseButton';
   ProductScreen.addControlButton({
	   component: CreatePurchaseButton,
	   condition: function() {
		   return this.env.pos.config.create_po;
	   },
   });
   Registries.Component.add(CreatePurchaseButton);
   return CreatePurchaseButton;




});
