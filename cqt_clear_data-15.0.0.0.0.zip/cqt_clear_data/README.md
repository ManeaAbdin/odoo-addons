Mass Clear Data
=====================================

Odoo Version : Odoo 14.0 Community


Installation
==================================================================
Install the Application -> Apps -> Mass Clear Data(cqt_clear_data)



