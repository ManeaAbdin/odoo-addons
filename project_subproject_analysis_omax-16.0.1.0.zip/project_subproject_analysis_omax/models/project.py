# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _, tools, _lt
from odoo.exceptions import UserError
from collections import defaultdict
import json


class Project(models.Model):
    _inherit = 'project.project'

    show_all_tasks = fields.Boolean(string='Show all tasks(child of child)',default=lambda self: self.env.user.has_group('project_subproject_analysis_omax.group_show_all_tasks'))
    auto_manage_dates = fields.Boolean(string='Auto Manage Dates',default=lambda self: self.env.user.has_group('project_subproject_analysis_omax.group_manage_project_deadline'))
    auto_manage_timesheet = fields.Boolean(string='Record Sub-Project Timesheet hours',default=lambda self: self.env.user.has_group('project_subproject_analysis_omax.group_manage_project_timesheet'))
    #Update the recorded hours of the sub project timesheet
    show_nested_subprojects = fields.Boolean(string='Show Nested Subprojects',default=lambda self: self.env.user.has_group('project_subproject_analysis_omax.group_show_nested_subprojects'))

    def _get_all_subproject(self, depth=0):
        children = self.mapped('child_ids')
        if not children:
            return self.env['project.project']
        if depth == 1:
            return children
        sub_children = False
        sub_children = children.filtered(lambda r: r.parent_id.allow_subprojects == True and r.parent_id.show_all_tasks == True)._get_all_subproject(depth - 1)
        if sub_children:
            return children + sub_children.filtered(lambda r: r.parent_id.allow_subprojects == True and r.parent_id.show_all_tasks == True)
        else:
            return children.filtered(lambda r: r.parent_id.allow_subprojects == True and r.parent_id.show_all_tasks == True)

    #cust
    def _get_all_subproject_timesheet(self, depth=0):
        children = self.mapped('child_ids')
        if not children:
            return self.env['project.project']
        if depth == 1:
            return children
        sub_children = False
        sub_children = children.filtered(lambda r: r.parent_id.allow_subprojects == True)._get_all_subproject_timesheet(depth - 1)
        if sub_children:
            return children + sub_children.filtered(lambda r: r.parent_id.allow_subprojects == True)
        else:
            return children
            
    @api.depends('child_ids')
    def _compute_subproject_count(self):
        for project in self:
            if project.show_nested_subprojects:
                project.subproject_count = len(project._get_all_subproject())
            else:
                project.subproject_count = len(project.child_ids)

    def open_subprojects(self):
        child_ids = self.child_ids.ids
        if self.show_nested_subprojects:
            child_ids = (self._get_all_subproject()).ids
        return {
                'type': 'ir.actions.act_window',
                'name': _("Subprojects of "+ self.name),
                'res_model': 'project.project',
                'view_mode': 'kanban,tree,form',
                'views': [(self.env.ref('project.view_project_kanban').id, 'kanban'),(self.env.ref('project.view_project').id, 'tree')],
                'target':'self',
                'domain': [('id','in',child_ids)]
            }

    #default
    def _compute_task_count(self):
        #default
        task_data = self.env['project.task'].read_group(
            [('project_id', 'in', self.ids),
             '|',
                ('stage_id.fold', '=', False),
                ('stage_id', '=', False)],
            ['project_id', 'display_project_id:count'], ['project_id'])
        result_wo_subtask = defaultdict(int)
        result_with_subtasks = defaultdict(int)
        for data in task_data:
            result_wo_subtask[data['project_id'][0]] += data['display_project_id']
            result_with_subtasks[data['project_id'][0]] += data['project_id_count']
        for project in self:
            project.task_count = result_wo_subtask[project.id]
            project.task_count_with_subtasks = result_with_subtasks[project.id]
        #fns default   
        #cust
        project_task = self.env['project.task']
        for project in self:
            if project.show_all_tasks and project.allow_subprojects:
                sub_projects = project._get_all_subproject()
                project_list = []
                not_subproject = False
                if sub_projects:
                    not_subproject = sub_projects.filtered(lambda r: not r.allow_subprojects)
                    if not_subproject:
                        sub_projects -= not_subproject
                    project_list = sub_projects.ids
                project_list.append(project.id)
                #if project.show_all_tasks and project.allow_subprojects:
                task_rec = project_task.search([('project_id', 'in', project_list)])#,'|',('stage_id.fold', '=', False),('stage_id', '=', False)
                if not_subproject:
                    task_rec += project_task.search([('display_project_id', 'in', not_subproject.ids)])
                project.task_count_with_subtasks = len(task_rec)
                project.task_count = len(task_rec)
            
            if project.allow_subprojects and not project.show_all_tasks:
                task_rec = project_task.search([('project_id', '=', project.id)])#,'|',('stage_id.fold', '=', False),('stage_id', '=', False)
                project.task_count_with_subtasks = len(task_rec)
                project.task_count = len(task_rec)
        #fns cust

    #default
    def action_view_tasks(self):
        action = super(Project, self).action_view_tasks()
        ctx = dict(self.env.context)
        #cust
        project_task = self.env['project.task']
        if self.show_all_tasks and self.allow_subprojects:
            project_list = []
            sub_projects = self._get_all_subproject()
            not_subproject = False
            if sub_projects:
                ###
                not_subproject = sub_projects.filtered(lambda r: not r.allow_subprojects)
                if not_subproject:
                    sub_projects -= not_subproject
                project_list = sub_projects.ids
            project_list.append(self.id)
            task_rec = project_task.search([('project_id', 'in', project_list)])
            if not_subproject:
                task_rec += project_task.search([('display_project_id', 'in', not_subproject.ids)])
            
            action['domain'] = [('id', 'in', task_rec.ids)]
            #action['domain'] = [('project_id', 'in', project_list)]
            ctx.update({'search_default_project': 1})
            action['context'] = ctx
            #fns cust
        if self.allow_subprojects and not self.show_all_tasks:
            #project_list = []
            #project_list.append(self.id)
            action['domain'] = [('project_id', '=', self.id)]
            ctx.update({'search_default_project': 1})
            action['context'] = ctx
        return action

    #cust
    def get_parent_projects(self):
        project_lst = []
        project_rec = False
        rec = self
        while rec != False:
            project_lst.append(rec._origin.id)
            if rec.parent_id and rec.auto_manage_dates:
                rec = rec.parent_id
            else:
                rec = False
        if project_lst:
            project_rec = self.env['project.project'].browse(project_lst)
        return project_rec

    def write(self, vals):
        res = super(Project, self).write(vals)
        # child have not auto_manage_dates selection but,
        #parent have set and child dt > parent dt then execute
        for rec in self:
            if not rec.auto_manage_dates and rec.parent_id:
                if 'date' in vals and rec.parent_id.auto_manage_dates and rec.date:
                    if rec.date > rec.parent_id.date:
                        rec.parent_id.date = rec.date
                    else:
                        rec.parent_id._onchange_auto_manage_dates()
        return res

    #cust
    @api.onchange('auto_manage_dates', 'date', 'allow_subprojects', 'show_all_tasks')
    def _onchange_auto_manage_dates(self):
        if self.auto_manage_dates:
            ctx_task = False
            if self.env.context.get('task') and self.env.context.get('new_deadline'):
                ctx_task = self.env.context.get('task')
                new_deadline = self.env.context.get('new_deadline')
            #when only subprojects
            if self.allow_subprojects and not self.show_all_tasks:
                sub_projects = self._get_all_subproject()#get sub projects
                project_id_list = []
                if sub_projects:
                    project_id_list = sub_projects.ids 
                project_id_list.append(self._origin.id)
                project_rec = self.env['project.project'].browse(project_id_list)

                if project_rec:
                    #add r.id == self._origin.id in domain 
                    #because in onchange not get auto_manage_dates in existing rec.
                    project_rec = project_rec.filtered(lambda r: r.auto_manage_dates or r.id == self._origin.id)

                for project in project_rec:
                    task_ids = project.task_ids.filtered(lambda r: r.date_deadline and r.display_project_id.id == project.id)
                    if task_ids:
                        #set existing task's deadline base on context
                        #because onchange call that time not store value
                        if ctx_task:#this code for on change
                            rec = task_ids.filtered(lambda r: r.id == ctx_task._origin.id)
                            rec.date_deadline = new_deadline
                            if rec.parent_id:
                                sub_tasks = rec.parent_id._get_all_subtasks()
                                if sub_tasks:
                                    sub_tasks = sub_tasks.filtered(lambda r: r.date_deadline)
                                    if sub_tasks:
                                        #max date on task's sub task's parent_id
                                        max_sub_task_deadline = max(sub_tasks.mapped('date_deadline'))
                                        rec.parent_id.date_deadline = max_sub_task_deadline

                        #var for maximum date of tasks
                        max_task_deadline = max(task_ids.mapped('date_deadline'))

                        #set date in project and sub project
                        project.date = max_task_deadline

                        #parent projects check and set date
                        if project.parent_id:
                            #get parent projects
                            parent_projects = project.get_parent_projects().filtered(lambda r: r.auto_manage_dates)
                            for p_proj in parent_projects:
                                #parent project have only allow_subprojects 
                                if p_proj.allow_subprojects and not p_proj.show_all_tasks:
                                    task_ids = p_proj.task_ids.filtered(lambda r: r.date_deadline and r.display_project_id.id == p_proj.id)
                                    if task_ids:
                                        #var for maximum date of parent project tasks
                                        parent_max_deadline = max(task_ids.mapped('date_deadline'))
                                        if parent_max_deadline:
                                            if parent_max_deadline < max_task_deadline:
                                                p_proj.date = max_task_deadline#date set of parent proj
                                            else:
                                                p_proj.date = parent_max_deadline#date set of parent proj

                                #parent project have allow_subprojects and show_all_tasks
                                if p_proj.show_all_tasks and p_proj.allow_subprojects:
                                    task_rec = self.env['project.task'].search([('project_id', '=', p_proj.id),('date_deadline','!=', False)], order="date_deadline desc")
                                    if task_rec:
                                        #var for maximum date of parent project tasks
                                        parent_max_deadline = max_task_deadline

                                    for task in task_rec:
                                        #set value in parent_max_deadline
                                        if parent_max_deadline < task.date_deadline:
                                            parent_max_deadline = task.date_deadline
                                        #get task's sub task
                                        sub_tasks = task._get_all_subtasks()
                                        if sub_tasks:
                                            sub_tasks = sub_tasks.filtered(lambda r: r.date_deadline)
                                            if sub_tasks:
                                                #max date on task's sub task
                                                max_sub_task_deadline = max(sub_tasks.mapped('date_deadline'))
                                                if parent_max_deadline < max_sub_task_deadline:
                                                    parent_max_deadline = max_sub_task_deadline
                                        task.project_id.date = parent_max_deadline# date set of parent proj
                                        task.project_id.write({'date':parent_max_deadline})
                        self.date = max_task_deadline#set date main rec

            #when subprojects and show all tasks selected(main)
            if self.show_all_tasks and self.allow_subprojects:
                sub_projects = self._get_all_subproject()#get sub projects
                sub_projects = sub_projects.filtered(lambda r: r.auto_manage_dates)
                project_id_list = []
                if sub_projects:
                    project_id_list = sub_projects.ids 
                project_id_list.append(self._origin.id)
                project_rec = self.env['project.project'].browse(project_id_list)
                #add r.id == self._origin.id in domain 
                #because in onchange not get auto_manage_dates in existing rec.
                if project_rec:
                    project_rec = project_rec.filtered(lambda r: r.auto_manage_dates or r.id == self._origin.id)

                if project_rec:
                    #find all tasks and sub tasks
                    task_rec = self.env['project.task'].search([('project_id', 'in', project_rec.ids),('date_deadline','!=', False)], order="date_deadline desc")

                    #set existing task's deadline base on context when onchange call
                    #because onchange call that time not store value
                    if task_rec and ctx_task:#this code for on change
                        task = task_rec.filtered(lambda r: r.id == ctx_task._origin.id)
                        task.date_deadline = new_deadline
                        if task.parent_id:
                            sub_tasks = task.parent_id._get_all_subtasks()
                            if sub_tasks:
                                sub_tasks = sub_tasks.filtered(lambda r: r.date_deadline)
                                if sub_tasks:
                                    #max date on task's sub tasks
                                    max_sub_task_deadline = max(sub_tasks.mapped('date_deadline'))
                                    task.parent_id.date_deadline = max_sub_task_deadline

                    #var for maximum date of task and sub-task
                    if task_rec:
                        max_task_deadline = task_rec[0].date_deadline

                    for task in task_rec:
                        #get task's sub task
                        sub_tasks = task._get_all_subtasks()

                        #set value in max_task_deadline
                        if max_task_deadline < task.date_deadline:
                            max_task_deadline = task.date_deadline

                        if sub_tasks:
                            sub_tasks = sub_tasks.filtered(lambda r: r.date_deadline)
                            if sub_tasks:
                                #max date on task's sub task
                                max_sub_task_deadline = max(sub_tasks.mapped('date_deadline'))
                                task.date_deadline = max_sub_task_deadline#parent task's deadline updt
                                ##tri comment
                                task_project_id_task_rec = self.env['project.task'].search([('project_id', '=', task.project_id.id),('date_deadline','!=', False)], order="date_deadline desc")
                                if task_project_id_task_rec:
                                    if task_project_id_task_rec[0].date_deadline < max_sub_task_deadline:
                                        task.project_id.date = max_sub_task_deadline
                                        task.project_id.write({'date':max_sub_task_deadline})
                                    else:
                                        task.project_id.date = task_project_id_task_rec[0].date_deadline
                                        task.project_id.write({'date':task_project_id_task_rec[0].date_deadline})
                                else:
                                    task.project_id.date = max_sub_task_deadline
                                    task.project_id.write({'date':max_sub_task_deadline})
                                        
                                #task.project_id.date = max_sub_task_deadline#parent task's proj date updts
                                #task.project_id.write({'date':max_sub_task_deadline})
                                #set value in max_task_deadline
                                if max_task_deadline < max_sub_task_deadline:
                                    max_task_deadline = max_sub_task_deadline
                        self.date = max_task_deadline#set date main rec

                    #parents project date set
                    if task_rec:
                        parent_projects = self.get_parent_projects()
                        for p_proj in parent_projects:
                            #parent project have only allow_subprojects 
                            if p_proj.allow_subprojects and not p_proj.show_all_tasks:
                                task_ids = p_proj.task_ids.filtered(lambda r: r.date_deadline and r.display_project_id.id == p_proj.id)
                                if task_ids:
                                    parent_max_deadline = max(task_ids.mapped('date_deadline'))
                                    if parent_max_deadline:
                                        if parent_max_deadline < max_task_deadline:
                                            p_proj.date = max_task_deadline
                                        else:
                                            p_proj.date = parent_max_deadline
                            #parent project have allow_subprojects and show_all_tasks
                            if p_proj.show_all_tasks and p_proj.allow_subprojects:
                                task_rec = self.env['project.task'].search([('project_id', '=', p_proj.id),('date_deadline','!=', False)], order="date_deadline desc")
                                #var for maximum date of parent project task and sub-task
                                if task_rec:
                                    parent_max_deadline = max_task_deadline
                                for task in task_rec:
                                    #set value in parent_max_deadline
                                    if parent_max_deadline < task.date_deadline:
                                        parent_max_deadline = task.date_deadline
                                    #get task's sub task
                                    sub_tasks = task._get_all_subtasks()
                                    if sub_tasks:
                                        sub_tasks = sub_tasks.filtered(lambda r: r.date_deadline)
                                        if sub_tasks:
                                            #max date on task's sub tasks
                                            max_sub_task_deadline = max(sub_tasks.mapped('date_deadline'))
                                            if parent_max_deadline < max_sub_task_deadline:
                                                parent_max_deadline = max_sub_task_deadline
                                    task.project_id.date = parent_max_deadline# date set of parent proj
                                    task.project_id.write({'date':parent_max_deadline})

            #when not select subprojects
            if not self.allow_subprojects:
                max_task_deadline = False
                task_ids = self.task_ids.filtered(lambda r: r.date_deadline and r.display_project_id.id == self._origin.id)
                #set existing task's deadline base on context when onchange call
                #because onchange call that time not store value
                if task_ids and ctx_task:#this code for on change
                    task = task_ids.filtered(lambda r: r.id == ctx_task._origin.id)
                    task.date_deadline = new_deadline
                    if task.parent_id:
                        sub_tasks = task.parent_id._get_all_subtasks()
                        if sub_tasks:
                            sub_tasks = sub_tasks.filtered(lambda r: r.date_deadline)
                            if sub_tasks:
                                #max date on task's sub tasks
                                max_sub_task_deadline = max(sub_tasks.mapped('date_deadline'))
                                task.parent_id.date_deadline = max_sub_task_deadline

                if task_ids:
                    max_task_deadline = max(task_ids.mapped('date_deadline'))
                if max_task_deadline:
                    self.date = max_task_deadline

    #func for manage show_Task smart button in proj form view
    def call_act_project_project_2_project_task_all(self):
        action = self.env["ir.actions.actions"]._for_xml_id("project.act_project_project_2_project_task_all")
        ctx = dict(self.env.context)
        #cust
        project_task = self.env['project.task']
        if self.show_all_tasks and self.allow_subprojects:
            project_list = []
            sub_projects = self._get_all_subproject()
            not_subproject = False
            if sub_projects:
                not_subproject = sub_projects.filtered(lambda r: not r.allow_subprojects)
                if not_subproject:
                    sub_projects -= not_subproject
                project_list = sub_projects.ids
            project_list.append(self.id)
            task_rec = project_task.search([('project_id', 'in', project_list)])
            if not_subproject:
                task_rec += project_task.search([('display_project_id', 'in', not_subproject.ids)])
            action['domain'] = [('id', 'in', task_rec.ids)]
            #action['domain'] = [('project_id', 'in', project_list)]
            ctx.update({'search_default_project': 1})
            action['context'] = ctx
            #fns cust

        if self.allow_subprojects and not self.show_all_tasks:
            #project_list = []
            #project_list.append(self.id)
            action['domain'] = [('project_id', '=', self.id)]
            ctx.update({'search_default_project': 1})
            action['context'] = ctx
        return action

    #default use for manage Project_Updates's Task smart button
    def _get_stat_buttons(self):
        buttons = super(Project, self)._get_stat_buttons()
        for button in buttons:
            if button.get('icon') == 'tasks':
                if self.show_all_tasks and self.allow_subprojects:
                    button.update({
                        'icon': 'tasks',
                        'text': _lt('Tasks'),
                        'number': self.task_count,
                        'action_type': 'object',
                        'action': 'call_act_project_project_2_project_task_all',
                        'additional_context': json.dumps({
                            'active_id': self.id,
                        }),
                        'show': True,
                        'sequence': 2,
                    })
        return buttons

    #timesheet hours count (ower)
    @api.depends('timesheet_ids')
    def _compute_total_timesheet_time(self):
        project_id = self
        domain = [('project_id', 'in', project_id.ids)]
        ####cust
        if self.auto_manage_timesheet:
            if self.allow_subprojects:
                task_rec = False
                sub_projects = self._get_all_subproject_timesheet()
                for sub_project in sub_projects:
                    if sub_project.parent_id:
                        if sub_project.parent_id.auto_manage_timesheet:
                            project_id += sub_project
                    else:
                        project_id += sub_project
        ####fns cust
        timesheets_read_group = self.env['account.analytic.line'].read_group(
            [('project_id', 'in', project_id.ids)],
            ['project_id', 'unit_amount', 'product_uom_id'],
            ['project_id', 'product_uom_id'],
            lazy=False)
        timesheet_time_dict = defaultdict(list)
        #uom_ids = set(self.timesheet_encode_uom_id.ids)
        timesheet_encode_uom_id = project_id.mapped('timesheet_encode_uom_id')
        uom_ids = set(timesheet_encode_uom_id.ids)

        for result in timesheets_read_group:
            uom_id = result['product_uom_id'] and result['product_uom_id'][0]
            if uom_id:
                uom_ids.add(uom_id)
            timesheet_time_dict[result['project_id'][0]].append((uom_id, result['unit_amount']))
        uoms_dict = {uom.id: uom for uom in self.env['uom.uom'].browse(uom_ids)}
        #for project in self:
        for project in project_id:
            # Timesheets may be stored in a different unit of measure, so first
            # we convert all of them to the reference unit
            # if the timesheet has no product_uom_id then we take the one of the project
            total_time = sum([
                unit_amount * uoms_dict.get(product_uom_id, project.timesheet_encode_uom_id).factor_inv
                for product_uom_id, unit_amount in timesheet_time_dict[project.id]
            ], 0.0)
            # Now convert to the proper unit of measure set in the settings
            total_time *= project.timesheet_encode_uom_id.factor
            ####
            if project.auto_manage_timesheet and project.allow_subprojects:
                sub_projects = project._get_all_subproject_timesheet()
                for sub_project in sub_projects:
                    sub_total_time = sum([
                        unit_amount * uoms_dict.get(product_uom_id, sub_project.timesheet_encode_uom_id).factor_inv
                        for product_uom_id, unit_amount in timesheet_time_dict[sub_project.id]
                    ], 0.0)
                    sub_total_time *= sub_project.timesheet_encode_uom_id.factor
                    total_time += sub_total_time
            ####
            project.total_timesheet_time = int(round(total_time))

    #timesheet hours view
    def action_show_timesheets_by_employee_invoice_type(self):
        action = self.env["ir.actions.actions"]._for_xml_id("hr_timesheet.timesheet_action_all")
        #Let's put the chart view first
        new_views = []
        #cust
        project_id = self
        domain = [('project_id', '=', self.id)]
        if self.auto_manage_timesheet:
            if self.allow_subprojects:
                sub_projects = self._get_all_subproject()
                #if sub_projects:
                for sub_project in sub_projects:
                    if sub_project.parent_id:
                        if sub_project.parent_id.auto_manage_timesheet:
                            project_id += sub_project
                    else:
                        project_id += sub_project
                #project_id += sub_projects
            domain = [('project_id', 'in', project_id.ids)]
        #finish cust
        for view in action['views']:
            new_views.insert(0, view) if view[1] == 'graph' else new_views.append(view)
        action.update({
            'display_name': _("Timesheets"),
            #'domain': [('project_id', '=', self.id)],
            'domain': domain,
            'context': {
                'default_project_id': self.id,
                'search_default_groupby_employee': True,
                'search_default_groupby_timesheet_invoice_type': True
            },
            'views': new_views
        })
        return action

    #func for manage timesheet_line link in proj kanban view
    def call_act_hr_timesheet_line_by_project(self):
        action = self.env["ir.actions.actions"]._for_xml_id("hr_timesheet.act_hr_timesheet_line_by_project")
        #cust
        project_id = self
        if self.auto_manage_timesheet:
            if self.allow_subprojects:
                sub_projects = self._get_all_subproject_timesheet()
                for sub_project in sub_projects:
                    if sub_project.parent_id:
                        if sub_project.parent_id.auto_manage_timesheet:
                            project_id += sub_project
                    else:
                        project_id += sub_project
        #finish cust
        
        action.update({
            'display_name': _("Timesheets"),
            'domain': [('project_id', '!=', False)],
            'context': {
                "search_default_project_id": [project_id.ids]
            },
            'views': [[False, "tree"], [False, "form"]],
            'view_mode': 'tree, kanban, form',
        })
        return action

    ##report functions
    def get_all_tasks(self):
        task_list = []
        current_tasks = self.task_ids.filtered(lambda l: l.display_project_id.id == self._origin.id)
        done_cancel_tasks = self.tasks.filtered(lambda l: l.display_project_id.id == self._origin.id and l.stage_id.fold == True)
        if done_cancel_tasks:
            current_tasks += done_cancel_tasks
        for task in current_tasks:
            task_list.append(task)
            sub_tasks = task._get_all_subtasks() 
            for sub_task in sub_tasks:
                task_list.append(sub_task)
        current_tasks = False
        sub_projects = self._get_all_subproject()
        for project_id in sub_projects:
            current_tasks = project_id.task_ids.filtered(lambda l: l.display_project_id.id == project_id._origin.id)
            for task in current_tasks:
                task_list.append(task)
                #curent proj have not tick sub project then,
                #only show display project
                if project_id.allow_subprojects:
                    sub_tasks = task._get_all_subtasks() 
                    for sub_task in sub_tasks:
                        task_list.append(sub_task)
        return task_list

    def get_all_sub_projects_report(self):
        project_list = []
        for child in self.child_ids:
            project_list.append(child)
            if child.allow_subprojects:
                sub_projects = child._get_all_subproject()#get sub projects
                for sub_project in sub_projects:
                    #if sub_project.parent_id.allow_subprojects:
                    project_list.append(sub_project)
        return project_list

    def get_all_sub_projects_individual_report(self):
        project_list = []
        project_list.append(self)
        if self.show_all_tasks:
            for child in self.child_ids:
                project_list.append(child)
                if child.allow_subprojects:
                    sub_projects = child._get_all_subproject()#get sub projects
                    for sub_project in sub_projects:
                        #if sub_project.parent_id.allow_subprojects:
                        project_list.append(sub_project)
        return project_list

    def get_all_tasks_individual(self):
        task_list = []
        current_tasks = self.task_ids.filtered(lambda l: l.display_project_id.id == self._origin.id)
        done_cancel_tasks = self.tasks.filtered(lambda l: l.display_project_id.id == self._origin.id and l.stage_id.fold == True)
        if done_cancel_tasks:
            current_tasks += done_cancel_tasks
        for task in current_tasks:
            task_list.append(task)
            sub_tasks = task._get_all_subtasks() 
            for sub_task in sub_tasks:
                task_list.append(sub_task)
        return task_list

    def get_timesheet_data(self):
        project_id = self
        if self.auto_manage_timesheet:
            if self.allow_subprojects:
                sub_projects = self._get_all_subproject_timesheet()
                for sub_project in sub_projects:
                    if sub_project.parent_id:
                        if sub_project.parent_id.auto_manage_timesheet:
                            project_id += sub_project
                    else:
                        project_id += sub_project
        time_sheet_lines = self.env['account.analytic.line'].search([('project_id', 'in', project_id.ids)])
        return time_sheet_lines

    def get_timesheet_projects(self):
        project_lst = []
        if self.auto_manage_timesheet:
            project_lst.append(self)
            if self.allow_subprojects:
                sub_projects = self._get_all_subproject_timesheet()
                for sub_project in sub_projects:
                    if sub_project.timesheet_ids:
                        if sub_project.parent_id:
                            if sub_project.parent_id.auto_manage_timesheet:
                                project_lst.append(sub_project)
                        else:
                            project_lst.append(sub_project)
        return project_lst


class Task(models.Model):
    _inherit = 'project.task'

    @api.model
    def create(self, vals):
        call_auto_manage_dates = False
        if 'date_deadline' in vals:
            call_auto_manage_dates = True
        res = super(Task, self).create(vals)
        if call_auto_manage_dates and res.project_id:
            if res.project_id.auto_manage_dates:
                res.project_id._onchange_auto_manage_dates()
        return res

    def apply_deadline(self):
        if self.date_deadline:
            if self.project_id.auto_manage_dates:
                self.project_id.with_context(task=self,new_deadline=self.date_deadline)._onchange_auto_manage_dates()
                #self.project_id._onchange_auto_manage_dates()
            else:
                raise UserError(_("'Auto Manage Dates' must be set in Project then apply deadline."))

    report_project_task_user_id = fields.Many2one('report.project.task.user', string='Pivot report')


class ReportProjectTaskUserNew(models.Model):
    _name = "report.project.task.user.new"
    _description = "Report Project Task Custom"
    
    name = fields.Char(string='Task', readonly=True)
    nbr = fields.Integer(string='# of Tasks', readonly=True)  # TDE FIXME master: rename into nbr_tasks
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    partner_id = fields.Many2one('res.partner', string='Customer', readonly=True)
    stage_id = fields.Many2one('project.task.type', string='Stage', readonly=True)
    task_id = fields.Many2one('project.task', string='Current project Tasks', readonly=True)
    sub_project_id = fields.Many2one('project.project', string='Sub Project', readonly=True)
    sub_project_task_id = fields.Many2one('project.task', string='Sub Project Tasks', readonly=True)
    project_id = fields.Many2one('project.project', string='Project', readonly=True)
    hours_effective = fields.Float(string='Effective Hours', readonly=True)

    def get_all_tasks_individual(self,project):
        task_list = []
        current_tasks = project.task_ids.filtered(lambda l: l.display_project_id.id == project._origin.id)
        done_cancel_tasks = project.tasks.filtered(lambda l: l.display_project_id.id == project._origin.id and l.stage_id.fold == True)
        if done_cancel_tasks:
            current_tasks += done_cancel_tasks
        for task in current_tasks:
            task_list.append(task)
            sub_tasks = task._get_all_subtasks() 
            for sub_task in sub_tasks:
                task_list.append(sub_task)
        return task_list

    @api.model
    def _get_view(self, view_id=None, view_type='form', **options):
        arch, view = super()._get_view(view_id, view_type, **options)
        existing= self.env['report.project.task.user.new'].search([])
        if existing:
            existing.unlink()
        Projects = self.env['project.project']
        Tasks = self.env['project.task']
        project_objs = Projects.sudo().search([('active', '=', True)])
        for project in project_objs:
            project_list = []
            if project.allow_subprojects:
                sub_projects = project._get_all_subproject()
                for sub_project in sub_projects:
                    project_list.append(sub_project)
            project_list.append(project)
            for project_lst in project_list:
                all_tasks = project_lst.get_all_tasks_individual()
                nbr = 0
                for t in all_tasks:
                    vals = {}
                    vals.update({
                        'project_id':project.id,
                        'name':t.name,
                        'nbr':nbr+1,
                        'company_id':t.company_id.id if t.company_id else False,
                        'partner_id':t.partner_id.id if t.partner_id else False,
                        'stage_id':t.stage_id.id if t.stage_id else False,
                        'hours_effective':t.effective_hours,
                        })
                    if t.project_id.id == project.id:
                        vals.update({'task_id':t.id})
                    if t.project_id.id != project.id:
                        vals.update({'sub_project_id':t.project_id.id})
                    else:
                        vals.update({'sub_project_id':t.project_id.id})
                    if t.project_id.id != project.id:
                        vals.update({'sub_project_task_id':t.id})
                    self.env['report.project.task.user.new'].create(vals)

        return arch, view
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
