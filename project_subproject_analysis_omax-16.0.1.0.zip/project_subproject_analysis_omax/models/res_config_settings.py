# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    group_show_nested_subprojects = fields.Boolean(string="Show Nested Subprojects",
    implied_group='project_subproject_analysis_omax.group_show_nested_subprojects')
    group_show_all_tasks = fields.Boolean(string="Show All Tasks (child of child)",
    implied_group='project_subproject_analysis_omax.group_show_all_tasks')
    group_manage_project_deadline = fields.Boolean(string="Auto manage Dates (Project deadline)",
    implied_group='project_subproject_analysis_omax.group_manage_project_deadline')
    group_manage_project_timesheet = fields.Boolean(string="Record Sub-Project Timesheet hours",
    implied_group='project_subproject_analysis_omax.group_manage_project_timesheet')

    @api.model
    def get_values(self):
        """get values from the fields"""
        res = super(ResConfigSettings, self).get_values()
        res.update(
            group_show_nested_subprojects = self.env['ir.config_parameter'].sudo().get_param('group_show_nested_subprojects'),
            group_show_all_tasks = self.env['ir.config_parameter'].sudo().get_param('group_show_all_tasks'),
            group_manage_project_deadline = self.env['ir.config_parameter'].sudo().get_param('group_manage_project_deadline'),
            group_manage_project_timesheet = self.env['ir.config_parameter'].sudo().get_param('group_manage_project_timesheet')
            )
        return res

    def set_values(self):
        """Set values in the fields"""
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('group_show_nested_subprojects', self.group_show_nested_subprojects)
        self.env['ir.config_parameter'].sudo().set_param('group_show_all_tasks', self.group_show_all_tasks)
        self.env['ir.config_parameter'].sudo().set_param('group_manage_project_deadline', self.group_manage_project_deadline)
        self.env['ir.config_parameter'].sudo().set_param('group_manage_project_timesheet',self.group_manage_project_timesheet)
# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
