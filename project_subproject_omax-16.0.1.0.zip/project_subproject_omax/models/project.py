# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models
from odoo import api, fields, models, _
from odoo.exceptions import RedirectWarning, UserError, ValidationError, AccessError


class Project(models.Model):
    _inherit = 'project.project'
    
    # If depth == 1, return only direct children
    # If depth == 3, return children to third generation
    # If depth <= 0, return all children without depth limit
    def _get_all_subproject(self, depth=0):
        children = self.mapped('child_ids')
        if not children:
            return self.env['project.project']
        if depth == 1:
            return children
        return children + children._get_all_subproject(depth - 1)
    
    @api.depends('child_ids')
    def _compute_subproject_count(self):
        for project in self:
            project.subproject_count = len(project.child_ids)
            
    parent_id = fields.Many2one('project.project', string='Parent Project', index=True)
    child_ids = fields.One2many('project.project', 'parent_id', string="Sub-Projects")
    subproject_count = fields.Integer("Sub-Project Count", compute='_compute_subproject_count')
    allow_subprojects = fields.Boolean('Sub-Projects',default=lambda self: self.env.user.has_group('project_subproject_omax.group_allow_subprojects'))
    
    def open_subprojects(self):
        return {
                'type': 'ir.actions.act_window',
                'name': _("Sub-projects"),
                'res_model': 'project.project',
                'view_mode': 'kanban,tree,form',
                'target':'self',
                'domain': [('id','in',self.child_ids.ids)]
            }
    def unlink(self):
        for project in self:
            if project.child_ids:
                raise ValidationError(_("You can't delete projects which has Sub-Project's"))
            if project.tasks:
                raise UserError(_("You cannot delete a Sub-Project containing tasks."))
        return super(Project,self).unlink()
    
