# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name' : 'Project Sub-project Management',
    'version' : '16.0.1.0',
    'description': """
            Project Sub-project Management
    """,
    'summary': """
        Project Sub Project Management
        Project Sub-Project Management, Parent-child projects, Project SubProject, Parent child projects, Parent project child projects, Sub projects hierarchy, Sub-projects hierarchy, Project Subproject hierarchy, projects hierarchy, project hierarchy, Parent projects child-projects Parent Project Subprojects, Parent Project Sub-Projects, task sub task manegement,
项目子项目管理, 父子项目, 项目子项目, 父子项目, 父项目子项目, 子项目层次结构, 子项目层次结构, 项目子项目层次结构, 项目层次结构, 项目层次结构, 父项目子项目 父项目子项目, 父项目子项目, 任务子任务管理、
Gestion des sous-projets, Projets parents-enfants, Sous-projets, Projets parents-enfants, Projets parents-enfants, Hiérarchie des sous-projets, Hiérarchie des sous-projets, Hiérarchie des projets, Hiérarchie des projets, Hiérarchie des projets, Projets parents-enfants, Sous-projets parents, Sous-projets parents, Gestion des sous-projets, Gestion des tâches et des sous-tâches,
Projekt-Unterprojekt-Management, Eltern-Kind-Projekte, Projekt-Unterprojekt, Eltern-Kind-Projekte, Elternprojekt-Kind-Projekte, Unterprojekte-Hierarchie, Unterprojekt-Hierarchie, Projekt-Unterprojekt-Hierarchie, Projekt-Hierarchie, Projekt-Hierarchie, Elternprojekte-Kind-Projekte Elternprojekt-Unterprojekte, Elternprojekt-Unterprojekte, Aufgabe-Unteraufgabe-Management,
Manajemen Sub Proyek, Manajemen Sub Proyek, Manajemen Sub Proyek, Manajemen Sub Proyek, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk, Manajemen Sub Proyek Induk,
Gestione dei sottoprogetti di progetto, progetti genitore-figlio, sottoprogetto di progetto, progetti genitore-figlio, progetti genitore-figlio, gerarchia dei sottoprogetti, gerarchia dei sottoprogetti di progetto, gerarchia dei progetti, gerarchia dei progetti, progetti genitore-figlio, sottoprogetti di progetto genitore, gestione dei sottoprogetti di progetto,
プロジェクトサブプロジェクト管理, 親子プロジェクト, プロジェクトサブプロジェクト, 親子プロジェクト, 親プロジェクト子プロジェクト, サブプロジェクト階層, サブプロジェクト階層, プロジェクトサブプロジェクト階層, プロジェクト階層, プロジェクト階層, 親プロジェクト子プロジェクト, 親プロジェクトサブプロジェクト, タスクサブタスク管理、
프로젝트 하위 프로젝트 관리, 상위-하위 프로젝트, 프로젝트 하위 프로젝트, 상위 하위 프로젝트, 상위 프로젝트 하위 프로젝트, 하위 프로젝트 계층, 하위 프로젝트 계층, 프로젝트 하위 프로젝트 계층, 프로젝트 계층, 프로젝트 계층, 상위 프로젝트 하위 프로젝트, 상위 프로젝트 하위 프로젝트, 상위 프로젝트 하위 프로젝트, 하위 프로젝트 하위 프로젝트, 작업 하위 작업 관리,
Zarządzanie podprojektami projektów, projekty rodzic-dziecko, podprojekt projektu, projekty rodzic-dziecko, projekty rodzic-dziecko, hierarchia podprojektów, hierarchia podprojektów, hierarchia podprojektów projektów, hierarchia projektów, hierarchia projektów, projekty rodzic-dziecko, projekty rodzic-dziecko, projekty rodzic-dziecko, zarządzanie podprojektami zadań,
Gestão de subprojectos de projectos, projectos pais-filhos, subprojectos de projectos, projectos pais-filhos, hierarquia de subprojectos, hierarquia de subprojectos, hierarquia de subprojectos, hierarquia de projectos, hierarquia de projectos, projectos pais-filhos, subprojectos de projectos pais, gestão de subtarefas,
Gerenciamento de subprojetos de projetos, projetos pai-filho, subprojetos de projetos, projetos pai-filho, projetos pai-filho, hierarquia de subprojetos, hierarquia de subprojetos, hierarquia de subprojetos de projetos, hierarquia de projetos, hierarquia de projetos, projetos pai-filho, subprojetos de projetos pai, gerenciamento de subtarefas,
Управление субпроектами, родительско-детские проекты, субпроект проекта, родительско-детские проекты, родительский проект-детские проекты, иерархия субпроектов, иерархия субпроектов, иерархия субпроектов проекта, иерархия проектов, иерархия проектов, родительские проекты-детские проекты, родительские субпроекты проекта, управление субпроектами проекта, управление задачами,
Gestión de subproyectos de proyectos, proyectos padres-hijos, subproyectos de proyectos, proyectos padres hijos, proyectos padres hijos, jerarquía de subproyectos, jerarquía de subproyectos, jerarquía de subproyectos de proyectos, jerarquía de proyectos, jerarquía de proyectos, proyectos padres hijos, subproyectos padres de proyectos, subproyectos padres de proyectos, gestión de subtareas de tareas,
Projekt- och delprojekthantering, föräldra-barn-projekt, projekt- och delprojekt, föräldra-barn-projekt, föräldra-barn-projekt, föräldra-barn-projekt, hierarki för delprojekt, hierarki för delprojekt, hierarki för projekt- och delprojekt, projekthierarki, projekthierarki, föräldra-barn-projekt, föräldra-barn-projekt, projekt- och delprojekt, projekt- och delprojekthantering, hantering av deluppgifter,
Proje Alt Proje Yönetimi, Ebeveyn-çocuk projeleri, Proje Alt Projesi, Ebeveyn çocuk projeleri, Ebeveyn proje çocuk projeleri, Alt projeler hiyerarşisi, Alt projeler hiyerarşisi, Proje Alt proje hiyerarşisi, projeler hiyerarşisi, proje hiyerarşisi, Ebeveyn projeler çocuk projeleri Ebeveyn Proje Alt Projeleri, Ebeveyn Proje Alt Projeleri, görev alt görev yönetimi,
Управління підпроектами проекту, Батьківський-дочірній проект, Підпроект проекту, Батьківський-дочірній проект, Батьківський проект дочірній проект, Ієрархія підпроектів, Ієрархія підпроектів, Ієрархія підпроектів проекту, Ієрархія проектів, Ієрархія проектів, Ієрархія проектів, Батьківський проект дочірній проект, Підпроекти батьківського проекту, Підпроекти батьківського проекту, Підпроекти батьківського проекту, Підпроекти батьківського проекту, Підпроекти батьківського проекту, Керування завданнями, Керування завданнями, Керування завданнями, Завдання,
مدیریت پروژه فرعی، پروژه های والدین-فرزند، پروژه های فرعی پروژه، پروژه های فرزند والدین، پروژه های فرزند پروژه والدین، سلسله مراتب پروژه های فرعی، سلسله مراتب پروژه های فرعی، سلسله مراتب پروژه های فرعی، سلسله مراتب پروژه ها، سلسله مراتب پروژه، پروژه های والدین پروژه های فرزند پروژه های فرعی پروژه های والدین ، پروژه های فرعی پروژه مادر، مدیریت وظایف فرعی،
إدارة المشروع الفرعي ، المشاريع الأصل-التابع ، المشروع الفرعي ، المشاريع الأصل الفرعي ، المشاريع الفرعية للمشروع الأصلي ، التدرج الهرمي للمشاريع الفرعية ، التدرج الهرمي للمشاريع الفرعية ، التسلسل الهرمي للمشروع الفرعي ، التدرج الهرمي للمشروعات ، التدرج الهرمي للمشروع ، المشاريع الأصلية المشاريع الفرعية المشاريع الفرعية للمشروع الأصلي ، المشاريع الفرعية للمشروع الأصلي ، إدارة المهام الفرعية للمهام ،
	""",
	'author': 'OMAX Informatics',
    'category': 'Services,Project Management',
    'website': 'https://www.omaxinformatics.com',
    'depends' : ['project'],
    'data': [
        'security/project_security.xml',
        'views/project.xml',
        'views/res_config_settings_views.xml',
    ],
    'installable': True,
    'application': True,
    "images": ["static/description/banner.png",],
    'currency':'USD',
    'price': 20.0,
    'auto_install': False,
    'live_test_url': 'https://youtu.be/mot4DqBQ6TI',
    'license': 'OPL-1',
}

