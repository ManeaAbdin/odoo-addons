# -*- coding: utf-8 -*-

from odoo import api, fields, models, _


class SaleOrder(models.Model):
    _inherit = 'sale.order'
    _description = 'Sale Order Inherit'

    name = fields.Char(string='Order Reference', required=True, copy=False, readonly=False, index=True,
                       default=lambda self: _('New'))
    is_read = fields.Boolean('Is Readonly', compute='compute_user_right')

    def compute_user_right(self):
        for rec in self:
            if self.user_has_groups('edit_sequence_number_app.group_system_sale_sequence_number'):
                rec.is_read = True
            else:
                rec.is_read = False


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    name = fields.Char(string='Order Reference', required=True, copy=False, readonly=False, index=True,
                       default=lambda self: _('New'))
    is_read = fields.Boolean('Is Readonly', compute='compute_user_right')

    def compute_user_right(self):
        for rec in self:
            if self.user_has_groups('edit_sequence_number_app.group_system_purchase_sequence_number'):
                rec.is_read = True
            else:
                rec.is_read = False


class account_move(models.Model):
    _inherit = 'account.move'
    _description = 'account move Inherit'

    name = fields.Char(string='Number', required=True, readonly=False, copy=False, default='/')
    is_read = fields.Boolean('Is Readonly', compute='compute_user_right')

    def compute_user_right(self):
        for rec in self:
            if self.user_has_groups('edit_sequence_number_app.group_system_invoice_sequence_number'):
                rec.is_read = True
            else:
                rec.is_read = False


class Picking_inherit(models.Model):
    _inherit = "stock.picking"
    _description = 'stock picking Inherit'

    name = fields.Char(
        'Reference', default='/',
        copy=False, index=True,
    )
    is_read = fields.Boolean('Is Readonly', compute='compute_user_right')

    def compute_user_right(self):
        for rec in self:
            if self.user_has_groups('edit_sequence_number_app.group_system_stock_sequence_number'):
                rec.is_read = True
            else:
                rec.is_read = False
