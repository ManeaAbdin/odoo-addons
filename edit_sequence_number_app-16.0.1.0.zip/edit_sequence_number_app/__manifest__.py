# -*- coding: utf-8 -*-

{
    'name': 'All in One Edit Sequence in Sales, Purchase, Invoice and Inventory',
    "author": "Edge Technologies",
    'version': '16.0.1.0',
    'live_test_url':'https://youtu.be/PjO4-1p_bBs',
    "images":['static/description/main_screenshot.png'],
    'summary': 'Allow to edit sequence number on sales order edit sequence on purchase edit sequence on invoice edit sequence on picking edit sequence on sale edit sequence on accounting sale edit number purchase edit number invoice edit number manual sequence on sales',
    'description' :"""
        
        Edit sequence number in odoo,
        Edit sequence number in odoo,
        Edit sequence number for sales in odoo,
        Edit sequence number for purchase in odoo,
        Edit sequence number for inventory in odoo,
        Edit sequence number for customer invoice in odoo,
        Edit sequence number for vendor bill in odoo,
    
    """,
    'depends': ['account','purchase','stock','sale_management'],
    'license':'OPL-1',
    'data': [
        'security/edit_sequence_groups.xml',
        'views/edit_sequence_view.xml',
        
    ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
    'price': 10,
    'currency': "EUR",
    'category': 'Extra Tools',
}
