# -*- coding: utf-8 -*-
{
    'name': 'Purchase Receipt Note | Purchase Picking Note',
    'version': '1.0',
    'author': "Preway IT Solutions",
    'category': 'Purchase',
    'depends': ['purchase_stock'],
    'summary': 'This app helps you to add picking note on purchase order | GRN note from purchase order | Purhcase order receipt note | GRN note from purchase order | Purchase Order Picking Notes | Purchase Picking Notes to Purchase Orders',
    'description': """This app helps you to add picking note on purchase order""",
    'data': [
        'views/purchase_order_view.xml',
        'views/stock_picking_view.xml',
        'views/picking_report.xml',
    ],
    'price': 6.0,
    'currency': "EUR",
    "images":["static/description/Banner.png"],
    "license": "LGPL-3",
    'application': True,
    'installable': True,
}
