# -*- coding: utf-8 -*-
from odoo import fields, models, api


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    pw_picking_note = fields.Text(string='Delivery Note', related='purchase_id.pw_picking_note', store=True, readonly=False)
