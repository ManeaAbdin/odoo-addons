Print QR Codes:
=========================================================

Go to Setting / apps and search "Print QR / Print QR Codes" and Install

And, you are done with installation. Congratulations!